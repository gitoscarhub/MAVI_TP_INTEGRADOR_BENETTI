// stdafx.h: archivo de inclusi�n de los archivos de inclusi�n est�ndar del sistema
// o archivos de inclusi�n espec�ficos de un proyecto utilizados frecuentemente,
// pero rara vez modificados
//

#pragma once


#include <stdlib.h>
#include <time.h>
#include <stdlib.h>
#include <tchar.h>
#include <iostream>




// Encabezados adicionales que el programa necesita
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include "mira.h"
#include "enemigo.h"
#include "inocente.h"
#include "Fondo.h"
#include "salir.h"
#include "reiniciar.h"