// stdafx.cpp: archivo de c�digo fuente que contiene s�lo las inclusiones est�ndar
// BENETTI_JO_MAVI_TP_INTEGRADOR.cpp ser� el encabezado precompilado


#include "stdafx.h"

// Los encabezados adicionales que se necesitan estan STDAFX.H

